package com.digitals.admin.dao;

public class AdminDao {

}
