package com.digitals.admin.dao.impl;

public class AdminDaoImpl {

}
