package com.digitals.admin.svc.impl;

public class AdminServiceImpl {

}
