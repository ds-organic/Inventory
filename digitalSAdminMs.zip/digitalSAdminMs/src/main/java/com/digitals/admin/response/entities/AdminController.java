package com.digitals.admin.response.entities;

public class AdminController {

}
