package com.digitals.admin.svc;

public class AdminService {

}
